import './index.scss';

const Layout = () => {
    return(
        <div className='container'>
            <h1 className='head-tag animate__animated animate__bounceIn'>About Me!</h1>
            <p class="dark-psheen animate__animated animate__bounceIn animate__delay-1s">
            Hi, I'm a computer science graduate with good experience working with javascript, React.js and Vue.js;
            I've also good experience dealing with databases like MySQL and SQLite;
            I'm also interested in learning more about backedn technologies and I've learnt in the past few years
            PHP and laravel.
            I'm trying to learn and study to join a respectable compan and take part in the field and get better programming.
            I've made some projects using javascript and React.js.
            </p>
        </div>
    );
}
export default Layout;